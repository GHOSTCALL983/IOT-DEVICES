import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit
import paho.mqtt.client as mqtt
import threading
import mqtt_trigger

# Start the MQTT client
mqtt_trigger.start_mqtt()

app = Flask(__name__)
socketio = SocketIO(app)

MQTT_BROKER = "test.mosquitto.org"
MQTT_PORT = 1883
MQTT_TOPICS = [("status", 0), ("bandstatus", 0), ("medicinestatus", 0),
               ("dooropen", 0), ("doorclose", 0), ("defendmode", 0),
               ("intrusion", 0), ("intrusionpolice", 0), ("stop", 0),
               ("triggeralert", 0), ("emergency", 0), ("havemedicine", 0),
               ("panicmodeactive", 0), ("triggeremail", 0),
               ("intrusionemail", 0)]
topic_reminder_count = "numbermedicine"
topic_medicine_times = "recievetimemedicine"
topic_start_time = "initialtime"
topic_between_time = "betweentime"
topic_have_medicine = "havemedicine"

# Global variable to store the latest recipient email
latest_email = None

# Define the MQTT client
mqtt_client = mqtt.Client()


# Email sending function
def send_email(sender_email, receiver_email, subject, body, smtp_server,
               smtp_port, sender_password):
    try:
        message = MIMEMultipart()
        message['From'] = sender_email
        message['To'] = receiver_email
        message['Subject'] = subject
        message.attach(MIMEText(body, 'plain'))

        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, receiver_email, message.as_string())
        print("Email sent successfully!")
        server.quit()
    except Exception as e:
        print(f"Error sending email: {e}")


# Handle incoming MQTT messages
def on_message(client, userdata, message):
    global latest_email
    topic = message.topic.strip()
    payload = message.payload.decode("utf-8").strip()

    print(f"Received message: {payload} from topic: {topic}")

    topic_handlers = {
        topic_have_medicine: handle_medicine_topic,
        "panicmodeactive": handle_panic_mode_active,
        "emergency": handle_emergency_topic,
        "intrusionemail": handle_intrusion_topic,
        "triggeremail": handle_trigger_alert_topic,
    }

    if topic in topic_handlers:
        socketio.start_background_task(target=topic_handlers[topic],
                                       payload=payload)
    else:
        socketio.start_background_task(target=emit_mqtt_message,
                                       topic=topic,
                                       payload=payload)


# Specific topic handlers
def handle_medicine_topic(payload):
    message = "It's time to take medicine!" if payload == "1" else "You had your medicine! No medicines to take at this time."
    print(message)
    socketio.emit('medicine_alert', {'message': message})

    # Send email if payload is 1 and a recipient email is saved
    if payload == "1" and latest_email:
        print("Sending medicine reminder email...")
        send_email(sender_email="emailemergency520@gmail.com",
                   receiver_email=latest_email,
                   subject="Medicine Reminder",
                   body="This is a reminder to take your medicine.",
                   smtp_server="smtp.gmail.com",
                   smtp_port=587,
                   sender_password="kroy zicj okmk rrhd")
    elif not latest_email:
        print("No recipient email saved for medicine reminder!")


def handle_trigger_alert_topic(payload):
    try:
        print(f"Handling trigger alert with payload: {payload}"
              )  # Log the payload for debugging

        # Check if payload is '1' and if there's a valid email
        if payload == "1" and latest_email:
            print(
                f"Trigger alert activated, sending alert email to {latest_email}..."
            )  # Log for debugging

            # Send email for trigger alert
            send_email(
                sender_email="emailemergency520@gmail.com",
                receiver_email=latest_email,
                subject="FALLEN",
                body=
                "A trigger alert has been activated. The victim has fallen, please take necessary action.",
                smtp_server="smtp.gmail.com",
                smtp_port=587,
                sender_password="kroy zicj okmk rrhd")
            print("Trigger alert email sent successfully.")  # Log success
        else:
            print(
                f"No email sent. Payload: {payload}, Latest email: {latest_email}"
            )  # Log if email not sent
    except Exception as e:
        print(f"Error in handle_trigger_alert_topic: {e}")  # Log any exception


def handle_panic_mode_active(payload):
    if latest_email:
        print("Panic mode active, sending SOS email...")
        send_panic_email()
    else:
        print("No recipient email saved yet for Panic Mode!")


def handle_intrusion_topic(payload):
    if payload == "1" and latest_email:
        print("Intrusion detected, sending alert email...")
        send_email(
            sender_email="emailemergency520@gmail.com",
            receiver_email=latest_email,
            subject="Intrusion Alert",
            body=
            "An intrusion has been detected. Please take immediate action.",
            smtp_server="smtp.gmail.com",
            smtp_port=587,
            sender_password="kroy zicj okmk rrhd")


def handle_emergency_topic(payload):
    if payload == '1':  # Check if the payload is '1'
        if latest_email:
            print("Emergency alert: The user has not taken the medicine!")
            send_emergency_email()
        else:
            print("No recipient email saved for emergency alert!")
    else:
        print("No emergency detected, no action needed.")



# Helper functions to handle background tasks for emitting and email
def emit_mqtt_message(topic, payload):
    socketio.emit('mqtt_message', {'topic': topic, 'payload': payload})


def send_panic_email():
    send_email(
        sender_email="emailemergency520@gmail.com",
        receiver_email=latest_email,
        subject="SOS Alert: Panic Mode Activated",
        body=
        "This is an emergency SOS message triggered by the Panic Mode. Please take necessary action immediately.",
        smtp_server="smtp.gmail.com",
        smtp_port=587,
        sender_password="kroy zicj okmk rrhd")


def send_emergency_email():
    send_email(
        sender_email="emailemergency520@gmail.com",
        receiver_email=latest_email,
        subject="Complaint: Medicine Not Taken",
        body=
        "Despite the reminders, the user has not taken the medicine. Please take necessary actions.",
        smtp_server="smtp.gmail.com",
        smtp_port=587,
        sender_password="kroy zicj okmk rrhd")


# Listen for Panic Mode activation and publish to 'panicmodeactive' topic and send email
@socketio.on('panic_mode')
def handle_panic_mode(data=None):
    global latest_email
    if data is None or 'email' not in data:
        print("Error: No data or email address provided.")
        return

    receiver_email = data.get('email')
    latest_email = receiver_email

    if receiver_email:
        print(f"Panic mode activated, sending alert to {receiver_email}...")
        mqtt_client.publish('panicmodeactive', "1")
    else:
        print("Error: No email address provided.")


# Save recipient email route
@app.route('/send_email', methods=['POST'])
def save_email():
    global latest_email
    recipient_email = request.json.get('email')
    if recipient_email:
        latest_email = recipient_email
        send_email(
            sender_email="emailemergency520@gmail.com",
            receiver_email=recipient_email,
            subject="Test Email: IoT Devices Dashboard",
            body=
            "This is a test email to confirm the email setup for your IoT Devices Dashboard.",
            smtp_server="smtp.gmail.com",
            smtp_port=587,
            sender_password="kroy zicj okmk rrhd")
        return jsonify({'message': 'Email saved successfully'}), 200
    else:
        return jsonify({'error': 'No email provided'}), 400


# Handle device reset requests
@socketio.on('reset_device')
def handle_reset_device(data):
    topic = data.get('topic')
    mqtt_client.publish(topic, "1")
    print(f"Reset signal sent to {topic}")
    socketio.emit('mqtt_message', {'topic': topic, 'payload': '1'})


# Route to check if an email is already saved
@app.route('/check_email', methods=['GET'])
def check_email():
    if latest_email:
        return jsonify({"email_exists": True, "email": latest_email}), 200
    else:
        return jsonify({"email_exists": False}), 200


# Flask routes to serve individual device pages
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/monitor/<device>')
def monitor_device(device):
    return render_template(f'{device}.html')


# Submit reminder count and medicine times
@app.route('/submit_reminder_count', methods=['POST'])
def submit_reminder_count():
    data = request.json
    reminder_count = str(data.get('reminder_count'))
    mqtt_client.publish(topic_reminder_count, reminder_count)
    return jsonify({"status": "Reminder count submitted successfully."})


@app.route('/submit_times', methods=['POST'])
def submit_times():
    data = request.json
    times = data.get('times')
    for time in times:
        mqtt_client.publish(topic_medicine_times, time)
    return jsonify({"status": "Medicine times submitted successfully."})


@app.route('/submit_start_time', methods=['POST'])
def submit_start_time():
    data = request.json
    start_time = data.get('start_time')
    mqtt_client.publish(topic_start_time, str(start_time))
    return jsonify({"status": "Start time submitted successfully."})


@app.route('/submit_between_time', methods=['POST'])
def submit_between_time():
    data = request.json
    between_time = str(data.get('between_time'))
    mqtt_client.publish(topic_between_time, between_time)
    return jsonify({"status": "Between time submitted successfully."})


# MQTT setup
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT Broker!")
        mqtt_client.subscribe(MQTT_TOPICS)
    else:
        print(f"Failed to connect, return code {rc}")


mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message


# Listen for Defend Mode toggle and publish to 'defendmode' topic
@socketio.on('mqtt_message')
def handle_mqtt_message(data):
    topic = data.get('topic')
    payload = data.get('payload')

    if topic == "defendmode":
        print(f"Defend Mode Toggled, sending {payload} to {topic}")
        mqtt_client.publish(topic, payload)


# Start MQTT background thread
def mqtt_background():
    mqtt_client.connect(MQTT_BROKER, MQTT_PORT, 60)
    mqtt_client.loop_forever()


# Start the Flask-SocketIO server and MQTT client
if __name__ == "__main__":
    mqtt_thread = threading.Thread(target=mqtt_background)
    mqtt_thread.start()
    socketio.run(app, host='0.0.0.0', port=8080)
