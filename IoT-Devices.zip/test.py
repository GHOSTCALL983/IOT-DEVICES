import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Email sending function
def send_email(sender_email, receiver_email, subject, body, smtp_server, smtp_port, sender_password):
    try:
        message = MIMEMultipart()
        message['From'] = sender_email
        message['To'] = receiver_email
        message['Subject'] = subject
        message.attach(MIMEText(body, 'plain'))

        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, receiver_email, message.as_string())
        print("Email sent successfully!")
        server.quit()
    except Exception as e:
        print(f"Error sending email: {e}")

# Test the email sending functionality
if __name__ == "__main__":
    send_email(
        sender_email="emailemergency520@gmail.com",
        receiver_email="test@example.com",  # Replace with your test email
        subject="Test Email from test.py",
        body="This is a test email sent from the test.py script.",
        smtp_server="smtp.gmail.com",
        smtp_port=587,
        sender_password="kroy zicj okmk rrhd"
    )
