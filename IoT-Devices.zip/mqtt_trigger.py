import paho.mqtt.client as mqtt

# MQTT settings
broker = "test.mosquitto.org"
port = 1883
trigger_topic = "triggeralert"
email_topic = "triggeremail"
intrusion_topic = "intrusion"
intrusion_email_topic = "intrusionemail"


# Callback when a message is received
def on_message(client, userdata, msg):
    # Handle triggeralert topic
    if msg.topic == trigger_topic and msg.payload.decode() == '1':
        print("Trigger alert received. Sending '1' to triggeremail topic.")
        client.publish(email_topic, '1')

    # Handle intrusion topic
    elif msg.topic == intrusion_topic and msg.payload.decode() == '1':
        print("Intrusion alert received. Sending '1' to intrusionemail topic.")
        client.publish(intrusion_email_topic, '1')


client = mqtt.Client()
client.on_message = on_message


def start_mqtt():
    client.connect(broker, port)

    # Subscribe to both triggeralert and intrusion topics
    client.subscribe(trigger_topic)
    client.subscribe(intrusion_topic)

    client.loop_start()  # Starts the loop in the background


# Optionally stop the loop when done
def stop_mqtt():
    client.loop_stop()
